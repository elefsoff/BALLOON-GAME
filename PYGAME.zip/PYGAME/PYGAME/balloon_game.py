import pygame
import random
import sys
import sqlite3

# Αρχικοποίηση Pygame
pygame.init()

# Ορισμός των διαστάσεων του παραθύρου
WIDTH, HEIGHT = 600, 400
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Balloon Game")

# Χρώματα
WHITE = (255, 255, 255)

# Φόντο
background = pygame.image.load("background_image.png")

# Παίκτης
player_image = pygame.image.load("player_image.png")
player_rect = player_image.get_rect()
player_rect.centerx = WIDTH // 2
player_rect.bottom = HEIGHT - 10

# Εικόνα μπαλονιού
balloon_image = pygame.image.load("balloon_image.png")

# Εικόνα βόμβας
bomb_image = pygame.image.load("bomb_image.png")

# Λίστες για τα μπαλόνια και τις βόμβες
balloons = []
bombs = []

# Βαθμολογία
score = 0

# Ήχος
pop_sound = pygame.mixer.Sound("pop_sound.wav")  

# Διαχείριση βάσης δεδομένων SQLite
db_filename = "score_db.sqlite"
connection = sqlite3.connect(db_filename)
cursor = connection.cursor()
cursor.execute("CREATE TABLE IF NOT EXISTS scores (id INTEGER PRIMARY KEY, score INTEGER)")
connection.commit()

# Κλοιός εκδήλωσης QUIT
game_over = False

# Διαδρομή μπαλονιών και βομβών
balloon_speed = 5
bomb_speed = 5

# Διαρκής βρόχος
clock = pygame.time.Clock()
while not game_over:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            game_over = True

    # Κίνηση του παίκτη
    keys = pygame.key.get_pressed()
    player_rect.x += (keys[pygame.K_RIGHT] - keys[pygame.K_LEFT]) * 5
    player_rect.x = max(0, min(WIDTH - player_rect.width, player_rect.x))

    # Δημιουργία νέων μπαλονιών
    if random.random() < 0.02:
        balloon_rect = balloon_image.get_rect()
        balloon_rect.topleft = (random.randint(0, WIDTH - balloon_rect.width), 0)
        balloons.append(balloon_rect)

    # Δημιουργία νέων βομβών
    if random.random() < 0.01:
        bomb_rect = bomb_image.get_rect()
        bomb_rect.topleft = (random.randint(0, WIDTH - bomb_rect.width), 0)
        bombs.append(bomb_rect)

    # Κίνηση των μπαλόνιων
    for balloon_rect in balloons:
        balloon_rect.y += balloon_speed
        if balloon_rect.colliderect(player_rect):
            pop_sound.play()
            score += 1
            balloons.remove(balloon_rect)

    # Κίνηση των βομβών
    for bomb_rect in bombs:
        bomb_rect.y += bomb_speed
        if bomb_rect.colliderect(player_rect):
            pop_sound.play()
            game_over = True

    # Καθαρισμός μπαλονιών και βομβών που έχουν πέσει κάτω από την οθόνη
    balloons = [balloon_rect for balloon_rect in balloons if balloon_rect.bottom < HEIGHT]
    bombs = [bomb_rect for bomb_rect in bombs if bomb_rect.bottom < HEIGHT]

    # Ανανέωση της οθόνης
    screen.fill(WHITE)
    screen.blit(background, (0, 0))
    screen.blit(player_image, player_rect)

    for balloon_rect in balloons:
        screen.blit(balloon_image, balloon_rect)

    for bomb_rect in bombs:
        screen.blit(bomb_image, bomb_rect)

    pygame.display.flip()

    # Ρύθμιση της ταχύτητας του παιχνιδιού
    clock.tick(30)

    # Σταδιακή αύξηση της δυσκολίας
    if score > 10:
        balloon_speed = 7
        bomb_speed = 7
    elif score > 20:
        balloon_speed = 10
        bomb_speed = 10

# Εμφάνιση του μηνύματος "Game Over" και του σκορ
font = pygame.font.SysFont(None, 36)
text = font.render("Game Over! Score: {}".format(score), True, (255, 0, 0))
screen.blit(text, (WIDTH // 2 - text.get_width() // 2, HEIGHT // 2 - text.get_height() // 2))
pygame.display.flip()

# Αποθήκευση του σκορ στη βάση δεδομένων
cursor.execute("INSERT INTO scores (score) VALUES (?)", (score,))
connection.commit()
connection.close()

#Ανάκτηση 5 τελευταίων σκορ από τη βάση δεδομένων
connection = sqlite3.connect(db_filename)
cursor = connection.cursor()
cursor.execute("SELECT score FROM scores ORDER BY id DESC LIMIT 5")
last_scores = cursor.fetchall()
connection.close()

#Εμφάνιση 5 τελευταίων σκορ από τη βάση δεδομένων
font = pygame.font.SysFont(None, 24)

text_y = 10
for i, last_score in enumerate(last_scores):
    text = font.render("Top Score {}: {}".format(i+1, last_score[0]), True, (0, 0, 0))
    screen.blit(text, (10, text_y))
    text_y += 20

pygame.display.flip()


# Περιμένουμε για να επιτρέψουμε στον παίκτη να διαβάσει το μήνυμα "Game Over" και στη συνέχεια να επιλέξει έξοδο
waiting_for_exit = True
while waiting_for_exit:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            waiting_for_exit = False
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            waiting_for_exit = False

# Κλείσιμο του Pygame
pygame.quit()
sys.exit()